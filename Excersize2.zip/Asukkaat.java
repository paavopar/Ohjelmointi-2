
public class Asukkaat {
private String asukkaan_nimi;
private String asukkaan_syntymapaiva;

public Asukkaat(String uasukkaan_nimi, String uasukkaan_syntymapaiva) {
	this.asukkaan_nimi = uasukkaan_nimi;
	this.asukkaan_syntymapaiva = uasukkaan_syntymapaiva;
}
public String getAsukkaan_nimi() {
	return this.asukkaan_nimi;
}
public String getAsukkaan_syntymapaiva() {
	return this.asukkaan_syntymapaiva;
}


}
