package kotitehtava5;

public class Asukas {
	private String asukkaan_nimi;


	public Asukas(String uasukkaan_nimi) {
		this.asukkaan_nimi = uasukkaan_nimi;

	}
	public String getAsukkaan_nimi() {
		return this.asukkaan_nimi;
	}
	public void setAsukkaan_nimi(String asukkaan_nimi) {
		this.asukkaan_nimi = asukkaan_nimi;
	}


}
